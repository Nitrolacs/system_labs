var searchData=
[
  ['лабораторная_20работа_20№1_2e_20управление_20процессами_20в_20oc_20gnu_2flinux_0',['Лабораторная работа №1. Управление процессами в OC GNU/Linux',['../md__c___v_m__e_x_c_h_a_n_g_e_system_programming_1_lab__r_e_a_d_m_e.html',1,'']]]
];
