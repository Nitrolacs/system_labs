var searchData=
[
  ['real_0',['real',['../structcomplex.html#a06ed4269b34924d748f2f77b17db7d21',1,'complex']]]
];
