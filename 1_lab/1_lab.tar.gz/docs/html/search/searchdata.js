var indexSectionsWithContent =
{
  0: "acfimprstuил",
  1: "c",
  2: "cmsu",
  3: "cfmprst",
  4: "ir",
  5: "c",
  6: "aил"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Структуры данных",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Определения типов",
  6: "Страницы"
};

