var searchData=
[
  ['secondtest_0',['SecondTest',['../unit__tests_8c.html#ac38ee57536843403f061d19bff89de68',1,'unit_tests.c']]],
  ['spawn_1',['spawn',['../main_8c.html#a789b9483e76881cfcca6ce0c3e7a7367',1,'main.c']]],
  ['stringinput_2',['StringInput',['../child_8h.html#ab4425e3fc0e97bb8cbd8a985bd2b657a',1,'child.c']]]
];
