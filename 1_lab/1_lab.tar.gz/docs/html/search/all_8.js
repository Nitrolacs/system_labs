var searchData=
[
  ['thirdtest_0',['ThirdTest',['../unit__tests_8c.html#ad87bcd921f0a5160cf76db5a3345ed2b',1,'unit_tests.c']]],
  ['threestringoperation_1',['ThreeStringOperation',['../child_8h.html#a37f3c4010a738efd2d8c3ff4b06f3834',1,'child.c']]],
  ['twostringoperation_2',['TwoStringOperation',['../child_8h.html#a1ff07e48c4427b48211bdf440c75f22a',1,'child.c']]]
];
